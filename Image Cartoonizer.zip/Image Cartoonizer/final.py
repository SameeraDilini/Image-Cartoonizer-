from tkinter import filedialog
from tkinter import * 
import tkinter as tk
from tkinter import messagebox
from PIL import ImageTk,Image


import cv2
import numpy as np
from matplotlib import pyplot as plt
from PIL import Image,ImageEnhance
import os


HEIGHT=400
WIDTH=400

root=tk.Tk()

def callback():
    root.filename =  filedialog.askopenfilename(initialdir = "/",title = "Select file",filetypes = (("jpeg files","*.jpg"),("all files","*.*")))
    img_new = cv2.imread(root.filename)
    print (root.filename)
    color = cv2.bilateralFilter(img_new, 100, 80, 600) # add the bilateral filter
    gray = cv2.cvtColor(color, cv2.COLOR_BGR2GRAY) #convert the image rgb to gray
    gray = cv2.medianBlur(gray, 5) #blur the gray image
    edges = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 51, 43)
    cv2.imwrite("1.jpg",color)

    img=Image.open("1.jpg")

    enhancer3=ImageEnhance.Sharpness(img)
    image3=enhancer3.enhance(30)

    enhancer2=ImageEnhance.Contrast(image3)
    image2=enhancer2.enhance(3.0)

    image2.save("2.jpg")

    final = cv2.imread("2.jpg")

    cartoon = cv2.bitwise_and(final, final, mask=edges)
    rezize=cv2.resize(cartoon,(400,400))
    rezize_original=cv2.resize(img_new,(400,400))

    cv2.imshow("CARTOON",rezize)
    cv2.imshow("ORIGINAL",rezize_original)
    cv2.imwrite("D:\Semester 7\Image Processing\cartoonizer\Cartoon.jpg",rezize)
    
    
    
    

    try: 
        os.remove("1.jpg")
        os.remove("2.jpg")

    except: pass

    cv2.waitKey(0)
    cv2.destroyAllWindows()   

errmsg = 'Error!'

canvas = tk.Canvas(root, height=HEIGHT, width=WIDTH)
canvas.pack()

load = Image.open("D:\Semester 7\Image Processing\cartoonizer\\back.jpg")
render = ImageTk.PhotoImage(load)
background_label = tk.Label(root, image=render)
background_label.place(relwidth=1, relheight=1)

upper_frame = tk.Frame(root, bg='#34a338', bd=5)
upper_frame.place(relx=0.5, rely=0.05, relwidth=0.75, relheight=0.1, anchor='n')

name_tag = tk.Label(upper_frame, text="Photo to Cartoon")
name_tag.config(font=("Courier", 20))
name_tag.place(relwidth=1, relheight=1)

frame = tk.Frame(root, bg='pink', bd=5)
frame.place(relx=0.5, rely=0.2, relwidth=0.75, relheight=0.1, anchor='n')

entry = tk.Label(frame, text="Choose the Image",font=40)
entry.place(relwidth=0.65, relheight=1)

button = tk.Button(frame, text="Get Image", font=40, command=callback)
button.place(relx=0.7, relheight=1, relwidth=0.3)

lower_frame = tk.Frame(root, bg='purple', bd=10)
lower_frame.place(relx=0.5, rely=0.35, relwidth=0.75, relheight=0.6, anchor='n')

load_logo = Image.open("D:\Semester 7\Image Processing\cartoonizer\\frame.jpg").resize((800, 600),Image.ANTIALIAS)
render_logo = ImageTk.PhotoImage(load_logo)

label = tk.Label(lower_frame,image=render_logo,bg='#b877d9')
label.place(relwidth=1, relheight=1)

root.mainloop()
